# WHYNOT STUDIO Logo／Favicon 打包 — 2026-08-02

## 01_網站主Logo
- whynot-you-logo.svg（含星星，網頁 Header 用，不用動）

## 02_Favicon
- favicon.ico ← 最終版，直接覆蓋 public/favicon.ico
  - 16px：原本細線版（v1）
  - 32px／48px：加粗版（v2），小尺寸更清楚
- whynot-you-logo-favicon.svg（去星星的向量版，備用/放大用）
- favicon-16.png／favicon-32.png／favicon-48.png（個別尺寸 PNG，備用）
- apple-touch-icon.png（180px，iOS 加到主畫面用）

用法（HTML head）：
```html
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
```

## 03_黑底反白版
- whynot-you-logo-dark-circle.svg（含星星，白線稿＋黑底圓形，社群大頭貼／深色背景用）

---
備份時間：2026-08-02
